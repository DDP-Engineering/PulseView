PulseView / sigrok-cli for the Hantek DSO-3062L (Linux x86_64)
==============================================================

Built natively against Ubuntu 24.04 libraries. Runs on Ubuntu 24.04 (incl.
WSL) and compatible distributions once the runtime libraries below are
installed.

Runtime dependencies (once):
  sudo apt install libglib2.0-0 libzip4 libusb-1.0-0 libftdi1-2 \
    libglibmm-2.4-1t64 libqt5core5a libqt5gui5 libqt5widgets5 \
    libqt5svg5 python3 python3-numpy

Device access (once):
  sudo cp 60-hantek-dso3062l.rules /etc/udev/rules.d/
  sudo udevadm control --reload && sudo udevadm trigger
  (add yourself to the plugdev group if needed, then re-login)

Run:
  ./pulseview          # GUI
  ./sigrok-cli --driver hantek-dso3062l --scan

Capabilities and notes are identical to the Windows build; see the project
protocol reference. Use -O srzip (not CSV) for triggered captures.
